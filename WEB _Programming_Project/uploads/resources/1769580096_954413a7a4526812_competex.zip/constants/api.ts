// API Base URL Configuration
// If your Apache server runs on a different port (e.g., 8080), change it here.
// Do NOT use port 3308, that is for the Database connection only.
export const API_BASE_URL = "http://localhost/Competex/api";

export const API_BASE_URL = "http://localhost/Competex/api";

export const ENDPOINTS = {
    SIGNUP: `${API_BASE_URL}/signup.php`,
    LOGIN: `${API_BASE_URL}/login.php`,
    GET_NOTIFICATIONS: `${API_BASE_URL}/get_notifications.php`,
    GET_EVENTS: `${API_BASE_URL}/get_events.php`,
    GET_EVENT: (eventId: string) => `${API_BASE_URL}/get_event.php?event_id=${eventId}`,
    GET_EVENT_LEADERBOARD: (eventId: string) => `${API_BASE_URL}/get_event_leaderboard.php?event_id=${eventId}`,
    CREATE_TEAM: `${API_BASE_URL}/create_team.php`,
    GET_TEAMS: `${API_BASE_URL}/get_teams.php`,
    REQUEST_JOIN: `${API_BASE_URL}/request_join.php`,
    RESPOND_REQUEST: `${API_BASE_URL}/respond_request.php`, // { request_id, action: 'accept'|'reject', leader_id }
    GET_TEAM_REQUESTS: (teamId: string) => `${API_BASE_URL}/get_team_requests.php?team_id=${teamId}`,
    REMOVE_TEAM_MEMBER: `${API_BASE_URL}/remove_team_member.php`,
    REQUEST_EVENT_JOIN: `${API_BASE_URL}/request_event_join.php`,
    GET_TEAM_EVENT_STATUS: `${API_BASE_URL}/get_team_event_status.php`,
    GET_EVENT_REQUESTS: (eventId: string) => `${API_BASE_URL}/get_event_requests.php?event_id=${eventId}`,
    RESPOND_EVENT_REQUEST: `${API_BASE_URL}/respond_event_request.php`,
    GET_ORGANIZER_EVENTS: (organizerId: string) => `${API_BASE_URL}/get_organizer_events_with_requests.php?organizer_id=${organizerId}`,
    GET_EVENT_PARTICIPANTS: (eventId: string) => `${API_BASE_URL}/get_event_participants.php?event_id=${eventId}`,
    GET_USER_EVENT_STATUS: `${API_BASE_URL}/get_user_event_status.php`,
    GET_USER_TEAMS_FOR_EVENTS: (userId: string) => `${API_BASE_URL}/get_user_teams_for_events.php?user_id=${userId}`,
};

<?php
// Include the database connection file
require_once 'db_connect.php';

// Set headers to allow cross-origin requests
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// SQL query to fetch events
// We join with the 'users' table to get the name of the organizer using 'organizer_id'
// We select all fields from 'events' and the 'name' from 'users' aliased as 'organizer'
$sql = "SELECT e.id, e.title, e.description, e.category, e.mode, e.status, 
               e.date_display as date, e.start_date, e.venue, e.max_participants, 
               e.participants_count, e.image, e.prizes, e.tags, e.registration_type, e.max_teams,
               e.contact_email, e.contact_phone,
               u.name as organizer, u.email as user_email
        FROM events e
        LEFT JOIN users u ON e.organizer_id = u.id
        WHERE e.status IN ('Upcoming', 'Live')
        ORDER BY e.start_date ASC";

$result = $conn->query($sql);

$events = [];

if ($result) {
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Decode JSON fields back to arrays
            $row['prizes'] = json_decode($row['prizes']);
            $row['tags'] = json_decode($row['tags']);

            // Map keys to match frontend 'Event' type if necessary
            // The frontend expects: 
            // id, title, description, category, mode, status, date, startDate, venue, maxParticipants, participantsCount, image, prizes, tags, organizer

            // Adjust specific fields
            $row['startDate'] = $row['start_date'];
            $row['maxParticipants'] = (int) $row['max_participants']; // Ensure integer
            $row['participantsCount'] = (int) $row['participants_count']; // Ensure integer
            $row['registrationType'] = $row['registration_type'];
            $row['maxTeams'] = (int) $row['max_teams'];
            $row['organizerEmail'] = $row['contact_email'] ? $row['contact_email'] : $row['user_email'];
            $row['organizerPhone'] = $row['contact_phone'];

            // Remove snake_case keys that we re-mapped to camelCase to keep payload clean
            unset($row['start_date']);
            unset($row['max_participants']);
            unset($row['participants_count']);
            unset($row['date_display']); // mapped to 'date' in SQL alias
            unset($row['registration_type']);
            unset($row['max_teams']);
            unset($row['contact_email']);
            unset($row['contact_phone']);
            unset($row['user_email']); // derived from alias

            $events[] = $row;
        }
    }

    // Return the events array as JSON
    echo json_encode($events);
} else {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database error: " . $conn->error]);
}

$conn->close();
?>
<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once 'config/database.php';

$database = new Database();
$db = $database->getConnection();

$data = json_decode(file_get_contents("php://input"));

if(
    !empty($data->team_id) &&
    !empty($data->sender_id) &&
    !empty($data->receiver_id)
){
    try {
        // 1. Verify sender is the leader of the team
        $query = "SELECT leader_id FROM teams WHERE id = :team_id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(":team_id", $data->team_id);
        $stmt->execute();
        $team = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$team || $team['leader_id'] !== $data->sender_id) {
            echo json_encode(["status" => "error", "message" => "Only the team leader can invite members."]);
            exit;
        }

        // 2. Check if already invited or member
        $check_query = "SELECT id FROM team_invitations WHERE team_id = :team_id AND receiver_id = :receiver_id AND status = 'pending'";
        $stmt = $db->prepare($check_query);
        $stmt->bindParam(":team_id", $data->team_id);
        $stmt->bindParam(":receiver_id", $data->receiver_id);
        $stmt->execute();
        if($stmt->rowCount() > 0){
             echo json_encode(["status" => "error", "message" => "User already invited."]);
             exit;
        }

        $check_member = "SELECT user_id FROM team_members WHERE team_id = :team_id AND user_id = :receiver_id";
        $stmt = $db->prepare($check_member);
        $stmt->bindParam(":team_id", $data->team_id);
        $stmt->bindParam(":receiver_id", $data->receiver_id);
        $stmt->execute();
        if($stmt->rowCount() > 0){
             echo json_encode(["status" => "error", "message" => "User is already a member."]);
             exit;
        }

        // 3. Create Invitation
        $invitation_id = uniqid("inv_");
        $query = "INSERT INTO team_invitations SET id=:id, team_id=:team_id, sender_id=:sender_id, receiver_id=:receiver_id, created_at=:created_at";
        $stmt = $db->prepare($query);

        $created_at = date('Y-m-d H:i:s');

        $stmt->bindParam(":id", $invitation_id);
        $stmt->bindParam(":team_id", $data->team_id);
        $stmt->bindParam(":sender_id", $data->sender_id);
        $stmt->bindParam(":receiver_id", $data->receiver_id);
        $stmt->bindParam(":created_at", $created_at);

        if($stmt->execute()){
            // 4. Create Notification
            $notif_id = uniqid("notif_");
            $notif_msg = "You have been invited to join a team.";
            $notif_query = "INSERT INTO notifications SET id=:id, user_id=:user_id, message=:message, type='invite', created_at=:created_at";
            $stmt_notif = $db->prepare($notif_query);
            $stmt_notif->bindParam(":id", $notif_id);
            $stmt_notif->bindParam(":user_id", $data->receiver_id);
            $stmt_notif->bindParam(":message", $notif_msg);
            $stmt_notif->bindParam(":created_at", $created_at);
            $stmt_notif->execute();

            echo json_encode(["status" => "success", "message" => "Invitation sent successfully."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Unable to send invitation."]);
        }
    } catch(PDOException $e) {
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Incomplete data."]);
}
?>

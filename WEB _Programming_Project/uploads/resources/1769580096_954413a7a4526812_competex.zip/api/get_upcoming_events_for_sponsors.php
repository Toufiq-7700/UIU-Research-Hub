<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

include_once 'db_connect.php';

// Fetch upcoming events 
$sql = "SELECT e.id, e.title, e.start_date, e.date_display, e.venue, e.participants_count, 
        u.name as organizer_name, e.organizer_id
        FROM events e
        LEFT JOIN users u ON e.organizer_id = u.id
        WHERE e.status IN ('Upcoming', 'Live')
        ORDER BY e.start_date ASC
        LIMIT 10";

$result = $conn->query($sql);

$events = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $events[] = $row;
    }
}

echo json_encode(["status" => "success", "data" => $events]);
$conn->close();
?>
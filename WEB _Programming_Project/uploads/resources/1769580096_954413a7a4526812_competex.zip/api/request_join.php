<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

include_once 'db_connect.php';

$data = json_decode(file_get_contents("php://input"));

if (!isset($data->team_id) || !isset($data->user_id)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Missing team_id or user_id"]);
    exit();
}

$team_id = $conn->real_escape_string($data->team_id);
$user_id = $conn->real_escape_string($data->user_id);
$request_id = uniqid();

// 1. Check if already a member
$check_member = $conn->query("SELECT * FROM team_members WHERE team_id='$team_id' AND user_id='$user_id'");
if ($check_member->num_rows > 0) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Already a member"]);
    exit();
}

// 2. Check if request already pending
$check_request = $conn->query("SELECT * FROM team_requests WHERE team_id='$team_id' AND user_id='$user_id' AND status='pending'");
if ($check_request->num_rows > 0) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Request already pending"]);
    exit();
}

// 3. Insert Request
$sql = "INSERT INTO team_requests (id, team_id, user_id, status) VALUES ('$request_id', '$team_id', '$user_id', 'pending')";

if ($conn->query($sql)) {
    http_response_code(201);
    echo json_encode(["status" => "success", "message" => "Request sent successfully"]);
} else {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => $conn->error]);
}

$conn->close();
?>
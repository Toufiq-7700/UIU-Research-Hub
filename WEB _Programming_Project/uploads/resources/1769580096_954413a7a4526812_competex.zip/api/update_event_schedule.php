<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

include_once 'db_connect.php';

$data = json_decode(file_get_contents("php://input"));

if (!isset($data->event_id) || !isset($data->start_date) || !isset($data->date_display)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit();
}

$event_id = $conn->real_escape_string($data->event_id);
$start_date = $conn->real_escape_string($data->start_date); // Expecting YYYY-MM-DD HH:MM:SS
$date_display = $conn->real_escape_string($data->date_display); // e.g., "Jan 24, 2026"

// Update event schedule
$sql = "UPDATE events SET start_date = '$start_date', date_display = '$date_display' WHERE id = '$event_id'";

if ($conn->query($sql)) {
    echo json_encode(["status" => "success", "message" => "Event schedule updated successfully"]);
} else {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database error: " . $conn->error]);
}

$conn->close();
?>
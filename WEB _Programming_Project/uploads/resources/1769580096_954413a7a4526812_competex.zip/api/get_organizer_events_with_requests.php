<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

include_once 'db_connect.php';

$organizer_id = isset($_GET['organizer_id']) ? $_GET['organizer_id'] : null;

if (!$organizer_id) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Missing organizer_id"]);
    exit();
}

$organizer_id = $conn->real_escape_string($organizer_id);

// Fetch events created by organizer and count pending requests
$sql = "SELECT e.id, e.title, e.start_date, e.status, e.date_display, e.registration_type, e.image, e.mode, e.created_at,
        COUNT(er.id) as pending_requests 
        FROM events e 
        LEFT JOIN event_requests er ON e.id = er.event_id AND er.status = 'pending'
        WHERE e.organizer_id = '$organizer_id'
        GROUP BY e.id
        ORDER BY e.created_at DESC";

$result = $conn->query($sql);

$events = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $events[] = $row;
    }
}

echo json_encode(["status" => "success", "data" => $events]);
$conn->close();
?>
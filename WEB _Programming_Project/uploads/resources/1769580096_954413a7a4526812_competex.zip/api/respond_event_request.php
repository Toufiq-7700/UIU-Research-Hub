<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

include_once 'db_connect.php';

$data = json_decode(file_get_contents("php://input"));

if (!isset($data->request_id) || !isset($data->action)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Missing request_id or action"]);
    exit();
}

$request_id = $conn->real_escape_string($data->request_id);
$action = $conn->real_escape_string($data->action); // 'approved' or 'rejected'

if (!in_array($action, ['approved', 'rejected'])) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Invalid action"]);
    exit();
}

// 1. Update Request Status
$sql = "UPDATE event_requests SET status = '$action' WHERE id = '$request_id'";

if ($conn->query($sql)) {
    if ($action === 'approved') {
        // 2. Need to add to event_teams if approved
        // Fetch details from request first
        $req_query = $conn->query("SELECT * FROM event_requests WHERE id='$request_id'");
        $req_data = $req_query->fetch_assoc();

        if ($req_data) {
            $event_id = $req_data['event_id'];
            $team_id = $req_data['team_id'];
            $user_id = $req_data['user_id']; // Fetch user_id

            if ($team_id) {
                // Team Enrollment
                $enroll_id = uniqid('enr_');
                // Check if already there (idempotency)
                $check = $conn->query("SELECT * FROM event_teams WHERE event_id='$event_id' AND team_id='$team_id'");
                if ($check->num_rows == 0) {
                    $conn->query("INSERT INTO event_teams (id, event_id, team_id) VALUES ('$enroll_id', '$event_id', '$team_id')");
                }
            } else {
                // Individual Enrollment
                // Check if already there
                $check = $conn->query("SELECT * FROM event_participants WHERE event_id='$event_id' AND user_id='$user_id'");
                if ($check->num_rows == 0) {
                    // Assuming event_participants table exists and auto-generates ID or uses composite key?
                    // If we follow the schema pattern: `id, event_id, user_id`
                    $part_id = uniqid('part_');
                    $conn->query("INSERT INTO event_participants (id, event_id, user_id) VALUES ('$part_id', '$event_id', '$user_id')");
                }
            }
        }
    }

    echo json_encode(["status" => "success", "message" => "Request $action successfully"]);
} else {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database error: " . $conn->error]);
}

$conn->close();
?>
<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once 'config/database.php';

$database = new Database();
$db = $database->getConnection();

$data = json_decode(file_get_contents("php://input"));

if(
    !empty($data->invitation_id) &&
    !empty($data->response) // 'accept' or 'reject'
){
    try {
        $db->beginTransaction();

        // 1. Get invitation details
        $query = "SELECT * FROM team_invitations WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(":id", $data->invitation_id);
        $stmt->execute();
        $invite = $stmt->fetch(PDO::FETCH_ASSOC);

        if(!$invite){
            echo json_encode(["status" => "error", "message" => "Invitation not found."]);
            exit;
        }

        // 2. Update status
        $status = ($data->response === 'accept') ? 'accepted' : 'rejected';
        $update_query = "UPDATE team_invitations SET status = :status WHERE id = :id";
        $stmt = $db->prepare($update_query);
        $stmt->bindParam(":status", $status);
        $stmt->bindParam(":id", $data->invitation_id);
        $stmt->execute();

        // 3. If accepted, add to team members
        if($status === 'accepted'){
            // Check if already member (double check)
            $check = "SELECT user_id FROM team_members WHERE team_id = :team_id AND user_id = :user_id";
            $stmt = $db->prepare($check);
            $stmt->bindParam(":team_id", $invite['team_id']);
            $stmt->bindParam(":user_id", $invite['receiver_id']);
            $stmt->execute();
            
            if($stmt->rowCount() == 0){
                $add_query = "INSERT INTO team_members (team_id, user_id) VALUES (:team_id, :user_id)";
                $stmt = $db->prepare($add_query);
                $stmt->bindParam(":team_id", $invite['team_id']);
                $stmt->bindParam(":user_id", $invite['receiver_id']);
                $stmt->execute();
            }
        }

        $db->commit();
        echo json_encode(["status" => "success", "message" => "Invitation " . $status]);

    } catch(PDOException $e) {
        $db->rollBack();
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Incomplete data."]);
}
?>

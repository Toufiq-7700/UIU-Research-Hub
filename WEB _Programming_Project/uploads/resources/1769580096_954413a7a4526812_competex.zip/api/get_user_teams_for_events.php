<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include_once 'db_connect.php';

if (!isset($_GET['user_id'])) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Missing user_id"]);
    exit();
}

$user_id = $conn->real_escape_string($_GET['user_id']);

// Query to get teams the user is a member of, AND that have applied to an event
$sql = "SELECT 
            t.id as team_id,
            t.name as team_name,
            t.leader_id,
            e.id as event_id,
            e.title as event_title,
            e.image as event_image,
            er.status as request_status,
            er.created_at as requested_at
        FROM team_members tm
        JOIN teams t ON tm.team_id = t.id
        JOIN event_requests er ON t.id = er.team_id
        JOIN events e ON er.event_id = e.id
        WHERE tm.user_id = '$user_id'
        ORDER BY er.created_at DESC";

$result = $conn->query($sql);

$teams = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $row['is_leader'] = ($row['leader_id'] === $user_id);

        // Fetch member count for the team
        $t_id = $row['team_id'];
        $count_res = $conn->query("SELECT COUNT(*) as c FROM team_members WHERE team_id='$t_id'");
        $count_row = $count_res->fetch_assoc();
        $row['member_count'] = $count_row['c'];

        $teams[] = $row;
    }
    echo json_encode(["status" => "success", "data" => $teams]);
} else {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database error: " . $conn->error]);
}

$conn->close();
?>
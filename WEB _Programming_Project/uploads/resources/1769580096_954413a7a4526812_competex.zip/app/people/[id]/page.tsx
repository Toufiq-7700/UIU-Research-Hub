"use client";

import { use } from "react";
import { Navbar } from "@/components/ui/Navbar";
import { PublicProfile } from "@/components/profile/PublicProfile";
import { useStore } from "@/store/useStore";
import { useEffect, useState } from "react";

interface ProfilePageProps {
    params: Promise<{ id: string }>;
}

export default function UserProfilePage({ params }: ProfilePageProps) {
    const { id } = use(params);
    const { setActiveDirectMessageUser } = useStore();
    const [scrolled, setScrolled] = useState(false);

    // State for dynamic data
    const [user, setUser] = useState<any>(null); // Using any temporarily to bypass strict User type diffs if any, checking type later
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const handleScroll = () => setScrolled(window.scrollY > 20);
        window.addEventListener("scroll", handleScroll);

        // Fetch User Data
        async function fetchUser() {
            try {
                const response = await fetch(`http://localhost/Competex/api/get_profile.php?user_id=${id}`);
                const data = await response.json();

                if (data.status === 'success' && data.user) {
                    // Normalize data to match User interface expected by PublicProfile
                    // The API returns distinct fields, we might need to map some if they don't match exactly 
                    // or rely on PublicProfile handling optional fields.
                    // For now, passing data.user directly as it seems to have most fields
                    setUser(data.user);
                } else {
                    setError("User not found");
                }
            } catch (err) {
                console.error("Error fetching profile:", err);
                setError("Failed to load profile");
            } finally {
                setIsLoading(false);
            }
        }

        fetchUser();

        return () => window.removeEventListener("scroll", handleScroll);
    }, [id]);

    if (isLoading) {
        return (
            <main className="min-h-screen bg-black">
                <Navbar />
                <div className="pt-32 flex justify-center items-center min-h-[60vh]">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent1"></div>
                </div>
            </main>
        );
    }

    if (error || !user) {
        // You could use notFound() here, but showing a UI message is often better for SPA transitions
        return (
            <main className="min-h-screen bg-black">
                <Navbar />
                <div className="pt-32 flex flex-col justify-center items-center min-h-[60vh] text-white">
                    <h2 className="text-2xl font-bold mb-4">{error || "User not found"}</h2>
                    <p className="text-gray-400">The agent you are looking for does not exist or has gone dark.</p>
                </div>
            </main>
        );
    }

    return (
        <main className="min-h-screen bg-black">
            <Navbar />

            <div className="pt-32 pb-20">
                <PublicProfile
                    user={user}
                    onMessageClick={(u) => setActiveDirectMessageUser(u)}
                />
            </div>
        </main>
    );
}

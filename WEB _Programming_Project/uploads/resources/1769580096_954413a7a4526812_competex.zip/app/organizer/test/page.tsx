export default function TestPage() {
    return <div>Test Page for Organizer Route</div>;
}

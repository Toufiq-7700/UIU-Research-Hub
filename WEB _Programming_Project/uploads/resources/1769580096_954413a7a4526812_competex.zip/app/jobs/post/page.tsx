"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
    Briefcase, MapPin, DollarSign, Clock,
    Eye, Edit3, Send, Plus, X
} from "lucide-react";

export default function PostJob() {
    const [formData, setFormData] = useState({
        title: "",
        company: "",
        location: "",
        salary: "",
        type: "Full-time",
        description: "",
        requirements: "" // Comma separated string
    });

    const [showPreview, setShowPreview] = useState(false); // Mobile toggle
    const [isPublishing, setIsPublishing] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handlePublish = (e: React.FormEvent) => {
        e.preventDefault();
        setIsPublishing(true);
        // Simulate API call
        setTimeout(() => {
            setIsPublishing(false);
            alert("Job posted successfully! (Simulation)");
        }, 2000);
    };

    const requirementsList = formData.requirements
        .split(",")
        .map(req => req.trim())
        .filter(req => req.length > 0);

    return (
        <div className="min-h-screen bg-black text-white pt-24 pb-20 px-6">
            <div className="max-w-7xl mx-auto">

                {/* Header */}
                <div className="flex items-center justify-between mb-8">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight">Post a <span className="text-accent1">Job</span></h1>
                        <p className="text-gray-400">Reach thousands of developers and designers.</p>
                    </div>
                    {/* Mobile Toggle */}
                    <button
                        onClick={() => setShowPreview(!showPreview)}
                        className="md:hidden flex items-center gap-2 px-4 py-2 bg-white/5 rounded-lg border border-white/10 text-sm font-medium"
                    >
                        {showPreview ? <Edit3 className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        {showPreview ? "Edit" : "Preview"}
                    </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 relative">

                    {/* Form Section */}
                    <motion.div
                        className={`space-y-8 ${showPreview ? "hidden md:block" : "block"}`}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                    >
                        <form onSubmit={handlePublish} className="space-y-6">

                            {/* Job Details */}
                            <div className="space-y-4 p-6 bg-[#0A0A0A] border border-white/5 rounded-xl">
                                <h3 className="text-lg font-semibold text-accent1 flex items-center gap-2">
                                    <Briefcase className="w-4 h-4" /> Job Details
                                </h3>

                                <div className="grid grid-cols-1 gap-4">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-400 mb-1">Job Title</label>
                                        <input
                                            type="text"
                                            name="title"
                                            value={formData.title}
                                            onChange={handleChange}
                                            placeholder="e.g. Senior Frontend Developer"
                                            className="w-full bg-black border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-accent1/50 focus:ring-1 focus:ring-accent1/50 transition-all placeholder:text-gray-700"
                                            required
                                        />
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-400 mb-1">Company Name</label>
                                            <input
                                                type="text"
                                                name="company"
                                                value={formData.company}
                                                onChange={handleChange}
                                                placeholder="e.g. Acme Corp"
                                                className="w-full bg-black border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-accent1/50 transition-all placeholder:text-gray-700"
                                                required
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-400 mb-1">Job Type</label>
                                            <select
                                                name="type"
                                                value={formData.type}
                                                onChange={handleChange}
                                                className="w-full bg-black border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-accent1/50 transition-all"
                                            >
                                                <option value="Full-time">Full-time</option>
                                                <option value="Part-time">Part-time</option>
                                                <option value="Contract">Contract</option>
                                                <option value="Internship">Internship</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-400 mb-1">Location</label>
                                            <div className="relative">
                                                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                                                <input
                                                    type="text"
                                                    name="location"
                                                    value={formData.location}
                                                    onChange={handleChange}
                                                    placeholder="e.g. Remote / NYC"
                                                    className="w-full bg-black border border-white/10 rounded-lg p-3 pl-9 text-white focus:outline-none focus:border-accent1/50 transition-all placeholder:text-gray-700"
                                                    required
                                                />
                                            </div>
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-400 mb-1">Salary Range</label>
                                            <div className="relative">
                                                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                                                <input
                                                    type="text"
                                                    name="salary"
                                                    value={formData.salary}
                                                    onChange={handleChange}
                                                    placeholder="e.g. $100k - $120k"
                                                    className="w-full bg-black border border-white/10 rounded-lg p-3 pl-9 text-white focus:outline-none focus:border-accent1/50 transition-all placeholder:text-gray-700"
                                                    required
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Description & Requirements */}
                            <div className="space-y-4 p-6 bg-[#0A0A0A] border border-white/5 rounded-xl">
                                <h3 className="text-lg font-semibold text-accent1 flex items-center gap-2">
                                    <Edit3 className="w-4 h-4" /> Description
                                </h3>

                                <div>
                                    <label className="block text-sm font-medium text-gray-400 mb-1">Job Description</label>
                                    <textarea
                                        name="description"
                                        value={formData.description}
                                        onChange={handleChange}
                                        rows={5}
                                        placeholder="Describe the role responsibilities and company culture..."
                                        className="w-full bg-black border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-accent1/50 transition-all placeholder:text-gray-700 resize-none"
                                        required
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-400 mb-1">
                                        Requirements <span className="text-gray-600 text-xs">(Comma separated)</span>
                                    </label>
                                    <input
                                        type="text"
                                        name="requirements"
                                        value={formData.requirements}
                                        onChange={handleChange}
                                        placeholder="e.g. React, Node.js, TypeScript, 3+ years exp"
                                        className="w-full bg-black border border-white/10 rounded-lg p-3 text-white focus:outline-none focus:border-accent1/50 transition-all placeholder:text-gray-700"
                                    />
                                </div>
                            </div>

                            <button
                                type="submit"
                                disabled={isPublishing}
                                className="w-full py-4 bg-accent1 text-black font-bold uppercase tracking-wider rounded-lg shadow-[0_0_20px_rgba(0,229,255,0.3)] hover:shadow-[0_0_30px_rgba(0,229,255,0.5)] hover:scale-[1.01] transition-all flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
                            >
                                {isPublishing ? (
                                    <>
                                        <span className="animate-spin w-5 h-5 border-2 border-black border-t-transparent rounded-full" />
                                        Publishing...
                                    </>
                                ) : (
                                    <>
                                        Publish Job Post <Send className="w-4 h-4" />
                                    </>
                                )}
                            </button>

                        </form>
                    </motion.div>

                    {/* Live Preview Section */}
                    <div className={`md:block ${showPreview ? "block" : "hidden"}`}>
                        <div className="sticky top-24 space-y-6">
                            <h2 className="text-xl font-bold text-gray-300 flex items-center gap-2">
                                <Eye className="w-5 h-5 text-accent2" /> Live Preview
                            </h2>

                            {/* Preview Card */}
                            <motion.div
                                layout
                                className="group relative bg-[#0A0A0A] border border-white/5 rounded-xl p-6 overflow-hidden shadow-2xl"
                            >
                                {/* Active Selection Border Effect */}
                                <div className="absolute inset-0 border border-accent1/30 rounded-xl pointer-events-none" />
                                <div className="absolute top-0 right-0 p-2 bg-accent1 text-black text-xs font-bold uppercase tracking-widest rounded-bl-lg">
                                    Preview
                                </div>

                                <div className="relative z-10 flex flex-col h-full space-y-4">
                                    <div className="flex justify-between items-start pr-12">
                                        <div>
                                            <h3 className="text-xl font-bold text-white group-hover:text-accent1 transition-colors line-clamp-1">
                                                {formData.title || "Job Title"}
                                            </h3>
                                            <p className="text-gray-400 text-sm font-medium">{formData.company || "Company Name"}</p>
                                        </div>
                                        <div className="p-2 bg-white/5 rounded-lg border border-white/5">
                                            <Briefcase className="w-5 h-5 text-accent1" />
                                        </div>
                                    </div>

                                    <div className="space-y-2 text-sm text-gray-400">
                                        <div className="flex items-center gap-2">
                                            <MapPin className="w-4 h-4 text-accent2" />
                                            {formData.location || "Location"}
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <DollarSign className="w-4 h-4 text-green-400" />
                                            {formData.salary || "Salary Range"}
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <Clock className="w-4 h-4 text-orange-400" />
                                            Posted Just Now
                                        </div>
                                    </div>

                                    <div className="flex flex-wrap gap-2 pt-2">
                                        {requirementsList.length > 0 ? (
                                            requirementsList.map((tag, i) => (
                                                <span key={i} className="px-2 py-1 bg-white/5 rounded text-xs text-gray-300 border border-white/5">
                                                    {tag}
                                                </span>
                                            ))
                                        ) : (
                                            <>
                                                <span className="px-2 py-1 bg-white/5 rounded text-xs text-gray-500 border border-white/5 border-dashed">Tag 1</span>
                                                <span className="px-2 py-1 bg-white/5 rounded text-xs text-gray-500 border border-white/5 border-dashed">Tag 2</span>
                                            </>
                                        )}
                                    </div>

                                    <div className="pt-4 border-t border-white/5 mt-4">
                                        <p className="text-sm text-gray-500 line-clamp-3 italic">
                                            {formData.description || "Job description will appear here..."}
                                        </p>
                                    </div>

                                    <div className="pt-4 mt-auto">
                                        <button disabled className="w-full py-3 bg-white/10 text-gray-400 font-bold uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 cursor-not-allowed">
                                            Apply Now
                                        </button>
                                    </div>
                                </div>
                            </motion.div>

                            <div className="p-4 bg-accent1/5 border border-accent1/10 rounded-lg text-sm text-gray-400">
                                <p><span className="text-accent1 font-bold">Tip:</span> Use precise location and salary ranges to attract 3x more applicants.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

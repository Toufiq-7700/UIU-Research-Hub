"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
    Search, MapPin, DollarSign, Clock,
    Briefcase, Filter, ArrowRight
} from "lucide-react";
import { cn } from "@/lib/utils";

// Mock Data
const JOBS = [
    {
        id: 1,
        title: "Senior Full Stack Developer",
        company: "TechCorp Inc.",
        location: "San Francisco, CA (Remote)",
        salary: "$120k - $160k",
        type: "Full-time",
        postedAt: 2,
        tags: ["React", "Node.js", "TypeScript", "AWS"],
        description: "We are looking for an experienced Full Stack Developer to lead our core product team..."
    },
    {
        id: 2,
        title: "Product Design Intern",
        company: "Creative Studio",
        location: "New York, NY",
        salary: "$30/hr",
        type: "Internship",
        postedAt: 1,
        tags: ["Figma", "UI/UX", "Prototyping"],
        description: "Join our award-winning design team and work on real-world client projects..."
    },
    {
        id: 3,
        title: "Backend Engineer",
        company: "DataFlow Systems",
        location: "Austin, TX/Remote",
        salary: "$110k - $140k",
        type: "Full-time",
        postedAt: 5,
        tags: ["Python", "Django", "PostgreSQL", "Redis"],
        description: "Scale our data processing pipeline handling millions of events per day..."
    },
    {
        id: 4,
        title: "Frontend Developer",
        company: "StartupX",
        location: "Remote",
        salary: "$90k - $120k",
        type: "Full-time",
        postedAt: 3,
        tags: ["Vue.js", "Tailwind", "JavaScript"],
        description: "Build beautiful and responsive user interfaces for our next-gen SaaS platform..."
    },
    {
        id: 5,
        title: "Marketing Intern",
        company: "Growth Hacking Co.",
        location: "Chicago, IL",
        salary: "$25/hr",
        type: "Internship",
        postedAt: 4,
        tags: ["SEO", "Content Marketing", "Social Media"],
        description: "Learn the ropes of digital marketing in a fast-paced environment..."
    }
];

const FILTERS = ["All", "Full-time", "Internship"];

export default function JobBoard() {
    const [searchQuery, setSearchQuery] = useState("");
    const [activeFilter, setActiveFilter] = useState("All");
    const [applyingId, setApplyingId] = useState<number | null>(null);

    const filteredJobs = JOBS.filter(job => {
        const matchesSearch = job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            job.company.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesFilter = activeFilter === "All" || job.type === activeFilter;
        return matchesSearch && matchesFilter;
    });

    const handleApply = (id: number) => {
        setApplyingId(id);
        setTimeout(() => {
            setApplyingId(null);
            alert("Application submitted successfully!"); // Temporary feedback
        }, 2000);
    };

    return (
        <div className="min-h-screen bg-black text-white pt-24 pb-20 px-6">
            <div className="max-w-7xl mx-auto space-y-12">

                {/* Header Section */}
                <div className="flex flex-col md:flex-row items-center justify-between gap-8">
                    <div className="space-y-2">
                        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
                            Career <span className="text-accent1">Hub</span>
                        </h1>
                        <p className="text-gray-400 max-w-md">
                            Discover your next big opportunity. Connect with top tech companies and innovative startups.
                        </p>
                    </div>

                    <div className="w-full md:w-auto flex flex-col sm:flex-row gap-4">
                        <div className="relative group">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-accent1 transition-colors" />
                            <input
                                type="text"
                                placeholder="Search jobs, companies..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="w-full sm:w-80 bg-white/5 border border-white/10 rounded-lg py-3 pl-10 pr-4 focus:outline-none focus:border-accent1/50 focus:bg-white/10 transition-all placeholder:text-gray-600"
                            />
                        </div>
                    </div>
                </div>

                {/* Filters */}
                <div className="flex flex-wrap items-center gap-3">
                    <Filter className="w-5 h-5 text-accent1 mr-2" />
                    {FILTERS.map(filter => (
                        <button
                            key={filter}
                            onClick={() => setActiveFilter(filter)}
                            className={cn(
                                "px-4 py-2 rounded-full text-sm font-medium border transition-all duration-300",
                                activeFilter === filter
                                    ? "bg-accent1/10 border-accent1 text-accent1 shadow-[0_0_10px_rgba(0,229,255,0.2)]"
                                    : "bg-white/5 border-white/10 text-gray-400 hover:bg-white/10 hover:border-white/20 hover:text-white"
                            )}
                        >
                            {filter}
                        </button>
                    ))}
                </div>

                {/* Job Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <AnimatePresence mode="popLayout">
                        {filteredJobs.map((job) => (
                            <motion.div
                                key={job.id}
                                layout
                                initial={{ opacity: 0, scale: 0.95 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.95 }}
                                transition={{ duration: 0.2 }}
                                className="group relative bg-[#0A0A0A] border border-white/5 rounded-xl p-6 hover:border-accent1/50 transition-all duration-300 hover:shadow-[0_0_20px_rgba(0,229,255,0.05)] overflow-hidden"
                            >
                                {/* Hover Gradient Effect */}
                                <div className="absolute inset-0 bg-gradient-to-br from-accent1/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

                                <div className="relative z-10 flex flex-col h-full space-y-4">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <h3 className="text-xl font-bold text-white group-hover:text-accent1 transition-colors line-clamp-1">
                                                {job.title}
                                            </h3>
                                            <p className="text-gray-400 text-sm font-medium">{job.company}</p>
                                        </div>
                                        <div className="p-2 bg-white/5 rounded-lg border border-white/5 group-hover:border-accent1/20 transition-colors">
                                            <Briefcase className="w-5 h-5 text-gray-400 group-hover:text-accent1 transition-colors" />
                                        </div>
                                    </div>

                                    <div className="space-y-2 text-sm text-gray-400">
                                        <div className="flex items-center gap-2">
                                            <MapPin className="w-4 h-4 text-accent2" />
                                            {job.location}
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <DollarSign className="w-4 h-4 text-green-400" />
                                            {job.salary}
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <Clock className="w-4 h-4 text-orange-400" />
                                            Posted {job.postedAt} days ago
                                        </div>
                                    </div>

                                    <div className="flex flex-wrap gap-2 pt-2">
                                        {job.tags.slice(0, 3).map(tag => (
                                            <span key={tag} className="px-2 py-1 bg-white/5 rounded text-xs text-gray-300 border border-white/5">
                                                {tag}
                                            </span>
                                        ))}
                                        {job.tags.length > 3 && (
                                            <span className="px-2 py-1 bg-white/5 rounded text-xs text-gray-300 border border-white/5">
                                                +{job.tags.length - 3}
                                            </span>
                                        )}
                                    </div>

                                    <div className="pt-4 mt-auto">
                                        <button
                                            onClick={() => handleApply(job.id)}
                                            disabled={applyingId === job.id}
                                            className="w-full py-3 bg-white text-black font-bold uppercase tracking-wider rounded-lg flex items-center justify-center gap-2 hover:bg-accent1 transition-colors group/btn disabled:opacity-70 disabled:cursor-not-allowed"
                                        >
                                            {applyingId === job.id ? (
                                                <>
                                                    <span className="animate-spin w-4 h-4 border-2 border-black border-t-transparent rounded-full" />
                                                    Sending...
                                                </>
                                            ) : (
                                                <>
                                                    Apply Now
                                                    <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                                                </>
                                            )}
                                        </button>
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                </div>

                {filteredJobs.length === 0 && (
                    <div className="text-center py-20">
                        <p className="text-gray-500 text-lg">No jobs found matching your criteria.</p>
                        <button
                            onClick={() => { setSearchQuery(""); setActiveFilter("All"); }}
                            className="mt-4 text-accent1 hover:underline"
                        >
                            Clear filters
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}
